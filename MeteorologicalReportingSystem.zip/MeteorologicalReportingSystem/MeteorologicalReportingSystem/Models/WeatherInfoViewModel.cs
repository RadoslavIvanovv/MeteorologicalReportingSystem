﻿namespace MeteorologicalReportingSystem.Models
{
    public class WeatherInfoViewModel
    { 
        public string City { get; set; }
        public int Temperature { get; set; }
        public double Pressure { get; set; }
    }
}
