﻿namespace MeteorologicalReportingSystem.Models.Enums
{
    public enum XMLStatusCode
    {
        Success,
        Unautorized,
        UnexpectedError,
        Offline
    }
}
