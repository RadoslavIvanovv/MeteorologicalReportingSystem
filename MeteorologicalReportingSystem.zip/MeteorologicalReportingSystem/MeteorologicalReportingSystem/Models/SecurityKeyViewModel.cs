﻿namespace MeteorologicalReportingSystem.Models
{
    public class SecurityKeyViewModel
    {
        public string SecurityKey { get; set; }
    }
}
